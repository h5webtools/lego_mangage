// app/router/news.js




module.exports = app => {

    require('./lego')(app);
    require('./legoEdit')(app);
    require('./theme')(app);
    require('./component')(app);
};