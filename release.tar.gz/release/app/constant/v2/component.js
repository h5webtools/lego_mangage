
// 还款状态
const componentGroup = {
    1: '通用组件',
    2: '活动组件',
    3: '推广组件'
  }
  
module.exports = {
 componentGroup
};
  
  